//Swift 3.0

//s.stringByTrimmingCharactersInSet()
//s.trimmingCharacters(in:)

//dismissViewControllerAnimated(true)
//dismiss(animated:true)

//UIColor.whiteColor()
//UIColor.white

//NSTextAlignment.Right
//NSTextAlignment.right
//.right


