//
//  Scene.swift
//  Que hay de nuevo
//
//  Created by Juan Gabriel Gomila Salas on 19/6/17.
//  Copyright © 2017 Frogames. All rights reserved.
//

import SpriteKit
import ARKit

class Scene: SKScene {
    
    override func didMove(to view: SKView) {
        // Setup your scene here
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
    }
}
