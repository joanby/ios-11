import UIKit

class ProgressBar: UIView {
    

}
