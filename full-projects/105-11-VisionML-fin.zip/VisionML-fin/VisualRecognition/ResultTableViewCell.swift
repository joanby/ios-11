import UIKit

class ResultTableViewCell: UITableViewCell {
    
    @IBOutlet weak var label : UILabel!
    @IBOutlet weak var score : UILabel!
    @IBOutlet weak var progress : ProgressBar!

}
