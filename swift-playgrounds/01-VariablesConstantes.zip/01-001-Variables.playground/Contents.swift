//: Playground - noun: a place where people can play

import UIKit

//Variables: valores que van a cambiar
//Constantes: valores de código que nunca cambiarán
let maximumNumberOfLogins = 10

var currentLoginAttempt = 0

var x = 0.0, y = 0.0, z = 0.0

//Variable que indica el mensaje de bienvenida a la app
var welcomeMessage: String

welcomeMessage = "Hola"

print(welcomeMessage)

welcomeMessage = "Bonjour"

print("Me acaban de saludar diciendo: \(welcomeMessage)")

//print([1,2,3], separator: "-", terminator: ".")

let language = "Swift"

var red, green, blue: Double

let π = 3.14159265

//let ☠️ = "muerte"

let 🐶🐮 = "perrovaca"

🐶🐮

let a3 = 45

let cat = "🐱"; print(cat)

/*
 Esto es un comentario
 que ocupa varias lineas
 de código en Swift.
 */

/*
 Esto es la primera linea del comentario.
 /*
 Esto es un segundo comentario, anidado al primero.
 */
 Esto es el comentario qeu finaliza el multilinea.
 */


